VS_SHADER_TYPE
--------------

.. versionadded:: 3.1

Set the Visual Studio shader type of a ``.hlsl`` source file.
