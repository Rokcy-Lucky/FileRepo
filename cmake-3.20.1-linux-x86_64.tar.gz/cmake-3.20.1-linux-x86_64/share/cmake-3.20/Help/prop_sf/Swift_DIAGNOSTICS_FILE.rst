Swift_DIAGNOSTICS_FILE
----------------------

.. versionadded:: 3.15

This property controls where the Swift diagnostics are serialized.
